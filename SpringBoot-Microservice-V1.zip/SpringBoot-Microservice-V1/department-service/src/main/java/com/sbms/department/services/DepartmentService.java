package com.sbms.department.services;

import com.sbms.department.entity.Department;
import com.sbms.department.repository.DepartmentRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    public Department saveDepartment(Department department) {
        log.info("Department Service: Inside Save Department Service");
        System.out.println("Department Service: Inside Save Department Service");
        return departmentRepository.save(department);
    }

    public Department findDepartmentById(Long departmentId) {
        log.info("Department Service: Inside Find Department By Id Service");
        return departmentRepository.findByDepartmentId(departmentId);
    }
}
