package com.sbms.department.controllers;

import com.sbms.department.entity.Department;
import com.sbms.department.services.DepartmentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/departments")
@Slf4j
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @PostMapping("/")
    public Department saveDepartment(@RequestBody Department department){
        log.info("Department Controller: Inside Save Department Method");
        System.out.println("Department Controller: Inside Save Department Method");
        return departmentService.saveDepartment(department);
    }

    @GetMapping("/{id}")
    public Department findDepartmentById(@PathVariable("id") Long departmentId){
        log.info("Department Controller: Inside Find Department By Id");
        return departmentService.findDepartmentById(departmentId);
    }
}
