package com.sbms.user.controllers;

import com.sbms.user.ValueObject.ResponseTemplateValueObject;
import com.sbms.user.entity.Users;
import com.sbms.user.entity.Users;
import com.sbms.user.services.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/")
    public Users saveUser(@RequestBody Users user){
        log.info("User Controller: Inside Save Controller");
         return userService.saveUser(user);
    }

//    @GetMapping("/{id}")
//    public User findUserById(@PathVariable("id") Long userId){
//        log.info("User Controller: Inside Find User By Id");
//        return userService.findUserById(userId);
//    }
    @GetMapping("/{id}")
    public ResponseTemplateValueObject getUserWithDeptById(@PathVariable("id") Long userId){
        log.info("User Controller: Inside Find User By Id");
        return userService.getUserWithDeptById(userId);
    }
}
